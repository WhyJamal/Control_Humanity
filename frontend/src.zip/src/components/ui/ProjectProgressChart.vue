<template>
  <div class="p-4 h-[400px] grid grid-cols-1 md:grid-cols-3 gap-4">
    <!-- 1. Donut Chart Card -->
    <div class="bg-white dark:bg-gray-800 rounded-xl shadow-md border border-gray-200 dark:border-gray-700 p-4">
      <div class="flex justify-between items-center mb-2">
        <h3 class="text-lg font-semibold text-gray-800 dark:text-white">Orders Statistics</h3>
        <button @click="refresh" class="text-sm text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200">
          Refresh
        </button>
      </div>
      <div class="h-50">
        <Doughnut :data="ordersData" :options="ordersOptions" />
      </div>
      <!-- legend -->
      <ul class="text-sm space-y-1">
        <li class="flex items-center">
          <span class="block w-3 h-3 bg-blue-500 rounded-full mr-2"></span> Direct +265
        </li>
        <li class="flex items-center">
          <span class="block w-3 h-3 bg-pink-500 rounded-full mr-2"></span> Social +75
        </li>
        <li class="flex items-center">
          <span class="block w-3 h-3 bg-green-500 rounded-full mr-2"></span> Marketing +102
        </li>
        <li class="flex items-center">
          <span class="block w-3 h-3 bg-indigo-500 rounded-full mr-2"></span> Affiliates +96
        </li>
      </ul>
    </div>

    <!-- 2. Bar Chart Card -->
    <div class="bg-white dark:bg-gray-800 rounded-xl shadow-md border border-gray-200 dark:border-gray-700 p-4">
      <h3 class="text-lg font-semibold text-gray-800 dark:text-white mb-4">Statistics</h3>
      <div class="h-64">
        <Bar :data="statsData" :options="statsOptions" />
      </div>
      <div class="mt-4 flex justify-between text-sm">
        <div>
          <div class="font-medium text-gray-800 dark:text-white">Revenue</div>
          <div class="text-green-600">\$29.5k</div>
        </div>
        <div>
          <div class="font-medium text-gray-800 dark:text-white">Payments</div>
          <div class="text-red-500">\$15.07k</div>
        </div>
        <div>
          <div class="font-medium text-gray-800 dark:text-white">Expenses</div>
          <div class="text-blue-600">\$71.5k</div>
        </div>
      </div>
    </div>

    <!-- 3. Line Chart Card -->
    <div class="bg-white dark:bg-gray-800 rounded-xl shadow-md border border-gray-200 dark:border-gray-700 p-4">
      <h3 class="text-lg font-semibold text-gray-800 dark:text-white mb-4">Total Revenue</h3>
      <div class="h-64">
        <Line :data="revenueData" :options="revenueOptions" />
      </div>
      <div class="mt-4 flex justify-between items-center text-sm">
        <div class="flex space-x-2">
          <span class="block w-3 h-3 bg-indigo-500 rounded-full"></span>
          <span>Total Income</span>
        </div>
        <div class="flex space-x-2">
          <span class="block w-3 h-3 bg-blue-500 rounded-full"></span>
          <span>Total Expenses</span>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { Doughnut, Bar, Line } from 'vue-chartjs'
import {
  Chart as ChartJS,
  Title,
  Tooltip,
  Legend,
  ArcElement,
  BarElement,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement
} from 'chart.js'

ChartJS.register(
  Title, Tooltip, Legend,
  ArcElement, BarElement, CategoryScale, LinearScale,
  PointElement, LineElement
)

export default {
  components: { Doughnut, Bar, Line },
  methods: {
    refresh() {
      // kerak bo'lsa API chaqiriq yoki yangilash logikasi
      console.log('Refresh clicked');
    }
  },
  data() {
    return {
      // 1. Orders Donut
      ordersData: {
        labels: ['Direct', 'Social', 'Marketing', 'Affiliates'],
        datasets: [{
          data: [265, 75, 102, 96],
          backgroundColor: ['#3B82F6','#EC4899','#10B981','#6366F1'],
          borderWidth: 0
        }]
      },
      ordersOptions: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: { legend: { display: false } },
        cutout: '70%'
      },

      // 2. Bar Statistics
      statsData: {
        labels: ['2019','2020','2021','2022','2023','2024','2025'],
        datasets: [{
          label: 'Stats',
          data: [20, 55, 100, 75, 80, 90, 50],
          backgroundColor: '#3B82F6'
        }]
      },
      statsOptions: {
        responsive: true,
        maintainAspectRatio: false,
        scales: {
          x: { grid: { display: false } },
          y: { beginAtZero: true }
        },
        plugins: { legend: { display: false } }
      },

      // 3. Line Total Revenue
      revenueData: {
        labels: ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'],
        datasets: [
          {
            label: 'Total Income',
            data: [65,78,66,70,80,90,85,88,92,85,80,75],
            fill: false,
            tension: 0.4,
            borderWidth: 2,
            pointRadius: 0
          },
          {
            label: 'Total Expenses',
            data: [30,40,35,45,50,55,60,58,65,62,60,55],
            fill: false,
            tension: 0.4,
            borderWidth: 2,
            pointRadius: 0,
            borderDash: [5,5]
          }
        ]
      },
      revenueOptions: {
        responsive: true,
        maintainAspectRatio: false,
        scales: {
          x: { grid: { display: false } },
          y: { beginAtZero: true }
        },
        plugins: {
          legend: {
            labels: { color: this.$root?.isDarkMode ? '#fff' : '#000' }
          }
        }
      }
    }
  }
}
</script>
