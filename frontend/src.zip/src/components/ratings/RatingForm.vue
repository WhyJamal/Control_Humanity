<template>
  <div>
    <h2 class="text-2xl">Rating Form</h2>
    <!-- Form to rate a user -->
  </div>
</template>

<script>
export default {
  name: 'RatingForm',
}
</script>
